import { useEffect, useMemo, useState } from 'react'
import { api } from './api'
import { Icon } from './icons'

const money = new Intl.NumberFormat('en-PH', {
  style: 'currency',
  currency: 'PHP',
  minimumFractionDigits: 2,
})

const dateTime = new Intl.DateTimeFormat('en-PH', {
  dateStyle: 'medium',
  timeStyle: 'short',
})

function Modal({ title, eyebrow = 'Administrator action', children, onClose }) {
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <span className="eyebrow">{eyebrow}</span>
            <h2>{title}</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Close">×</button>
        </div>
        {children}
      </section>
    </div>
  )
}

function TransactionRow({ tx }) {
  const outgoing = Number(tx.amount) < 0
  const titleMap = {
    DEPOSIT: 'Cash deposit',
    TRANSFER_OUT: 'Transfer sent',
    TRANSFER_IN: 'Transfer received',
    ADMIN_TOPUP: 'Admin top-up',
    ADMIN_DEBIT: 'Admin debit',
  }

  return (
    <div className="transaction-row">
      <div className={`tx-icon ${outgoing ? 'outgoing' : 'incoming'}`}>
        <Icon name={outgoing ? 'send' : 'plus'} size={18} />
      </div>
      <div className="tx-main">
        <strong>{titleMap[tx.type] || tx.type}</strong>
        <span>{tx.description || 'Banking transaction'}{tx.counterpartyAccountNumber ? ` · ${tx.counterpartyAccountNumber}` : ''}</span>
      </div>
      <div className="tx-meta">
        <strong className={outgoing ? 'negative' : 'positive'}>
          {outgoing ? '−' : '+'}{money.format(Math.abs(Number(tx.amount)))}
        </strong>
        <span>{dateTime.format(new Date(tx.createdAt))}</span>
      </div>
    </div>
  )
}

function MoneyForm({ mode, customer, onClose, onSuccess }) {
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const isDebit = mode === 'debit'

  async function submit(event) {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (isDebit) await api.adminDebit(customer.accountNumber, Number(amount), description)
      else await api.adminTopUp(customer.accountNumber, Number(amount), description)
      await onSuccess()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal title={`${isDebit ? 'Debit' : 'Top up'} ${customer.fullName}`} onClose={onClose}>
      <form className="modal-form" onSubmit={submit}>
        <div className="customer-summary-inline">
          <span>{customer.accountNumber}</span>
          <strong>{money.format(Number(customer.balance))}</strong>
        </div>
        {error && <div className="alert error">{error}</div>}
        <label>
          <span>Amount</span>
          <div className="money-input"><b>₱</b><input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required autoFocus /></div>
        </label>
        <label>
          <span>Reason / note</span>
          <input value={description} maxLength="160" onChange={(e) => setDescription(e.target.value)} placeholder={isDebit ? 'e.g. correction or fee reversal' : 'e.g. branch cash top-up'} />
        </label>
        <div className="modal-actions">
          <button type="button" className="secondary-button" onClick={onClose}>Cancel</button>
          <button className={isDebit ? 'danger-button' : 'primary-button'} disabled={loading}>
            {loading ? 'Processing…' : isDebit ? 'Debit customer' : 'Top up customer'}
          </button>
        </div>
      </form>
    </Modal>
  )
}

function OwnDeposit({ onClose, onSuccess }) {
  const [amount, setAmount] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  async function submit(event) {
    event.preventDefault(); setLoading(true); setError('')
    try { await api.deposit(Number(amount)); await onSuccess() } catch (err) { setError(err.message) } finally { setLoading(false) }
  }
  return <Modal title="Deposit to admin account" eyebrow="Admin wallet" onClose={onClose}><form className="modal-form" onSubmit={submit}>
    {error && <div className="alert error">{error}</div>}
    <label><span>Amount</span><div className="money-input"><b>₱</b><input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required autoFocus /></div></label>
    <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={loading}>{loading ? 'Depositing…' : 'Deposit'}</button></div>
  </form></Modal>
}

function OwnTransfer({ currentAccount, onClose, onSuccess }) {
  const [target, setTarget] = useState('100000001')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  async function submit(event) {
    event.preventDefault(); setLoading(true); setError('')
    try { await api.transfer(target, Number(amount), description); await onSuccess() } catch (err) { setError(err.message) } finally { setLoading(false) }
  }
  return <Modal title="Transfer from admin account" eyebrow="Admin wallet" onClose={onClose}><form className="modal-form" onSubmit={submit}>
    {error && <div className="alert error">{error}</div>}
    <label><span>From</span><input value={currentAccount} readOnly /></label>
    <label><span>Recipient account</span><input value={target} onChange={(e) => setTarget(e.target.value)} required /></label>
    <label><span>Amount</span><div className="money-input"><b>₱</b><input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required /></div></label>
    <label><span>Description</span><input value={description} maxLength="200" onChange={(e) => setDescription(e.target.value)} placeholder="Optional note" /></label>
    <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={loading}>{loading ? 'Sending…' : 'Send money'}</button></div>
  </form></Modal>
}

export default function AdminDashboard({ onUnauthenticated }) {
  const [account, setAccount] = useState(null)
  const [adminTransactions, setAdminTransactions] = useState([])
  const [customers, setCustomers] = useState([])
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const [selectedTransactions, setSelectedTransactions] = useState([])
  const [modal, setModal] = useState(null)
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')
  const [loadingCustomers, setLoadingCustomers] = useState(false)

  async function loadAdmin() {
    const [accountData, txPage] = await Promise.all([api.account(), api.transactions(0, 10)])
    setAccount(accountData)
    setAdminTransactions(txPage.content || [])
  }

  async function loadCustomers(term = search) {
    setLoadingCustomers(true)
    try {
      const page = await api.adminCustomers(term, 0, 50)
      setCustomers(page.content || [])
      setError('')
    } catch (err) {
      if (err.status === 401) onUnauthenticated()
      else setError(err.message)
    } finally {
      setLoadingCustomers(false)
    }
  }

  async function inspectCustomer(customer) {
    try {
      const page = await api.adminTransactions(customer.accountNumber, 0, 50)
      setSelected(customer)
      setSelectedTransactions(page.content || [])
      document.getElementById('customer-inspector')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    } catch (err) {
      setError(err.message)
    }
  }

  async function refreshSelected() {
    await Promise.all([loadCustomers(search), loadAdmin()])
    if (selected) {
      const customerPage = await api.adminCustomers(selected.accountNumber, 0, 1)
      const fresh = customerPage.content?.[0]
      if (fresh) {
        setSelected(fresh)
        const txPage = await api.adminTransactions(fresh.accountNumber, 0, 50)
        setSelectedTransactions(txPage.content || [])
      }
    }
  }

  useEffect(() => {
    Promise.all([loadAdmin(), loadCustomers('')]).catch((err) => {
      if (err.status === 401) onUnauthenticated()
      else setError(err.message)
    })
  }, [])

  const totalCustomerBalance = useMemo(
    () => customers.reduce((sum, customer) => sum + Number(customer.balance), 0),
    [customers],
  )

  function notify(message) {
    setToast(message)
    window.setTimeout(() => setToast(''), 2600)
  }

  async function logout() {
    try { await api.logout() } finally { onUnauthenticated() }
  }

  if (!account) return <div className="loading-screen">Loading administrator console…</div>

  return (
    <div className="app-shell admin-shell">
      <aside className="sidebar admin-sidebar">
        <div className="brand"><div className="brand-mark">N</div><span>Northstar</span></div>
        <span className="admin-pill">ADMIN CONSOLE</span>
        <nav>
          <a className="active" href="#admin-overview"><Icon name="home" /> Overview</a>
          <a href="#customers"><Icon name="users" /> Customers</a>
          <a href="#customer-inspector"><Icon name="history" /> Inspection</a>
        </nav>
        <div className="sidebar-foot">
          <span className="avatar">{account.fullName.charAt(0)}</span>
          <div><strong>{account.fullName}</strong><span>@{account.username} · ADMIN</span></div>
          <button className="icon-button" onClick={logout} title="Logout"><Icon name="logout" /></button>
        </div>
      </aside>

      <main className="dashboard admin-dashboard" id="admin-overview">
        <div className="mobile-admin-bar">
          <div className="brand"><div className="brand-mark">N</div><span>Northstar Admin</span></div>
          <button className="icon-button" onClick={logout} aria-label="Sign out"><Icon name="logout" /></button>
        </div>

        <header className="topbar admin-topbar">
          <div><span className="eyebrow">Administrator console</span><h1>Manage customer accounts.</h1><p className="muted admin-subtitle">Search customers, adjust balances, and inspect transaction activity from one responsive dashboard.</p></div>
          <button className="quiet-button desktop-signout" onClick={logout}><Icon name="logout" /> Sign out</button>
        </header>

        {error && <div className="alert error">{error}</div>}

        <section className="admin-stat-grid">
          <article className="admin-stat-card accent-stat"><span>Admin wallet</span><strong>{money.format(Number(account.balance))}</strong><small>{account.accountNumber}</small></article>
          <article className="admin-stat-card"><span>Visible customers</span><strong>{customers.length}</strong><small>Current search result</small></article>
          <article className="admin-stat-card"><span>Customer balances</span><strong>{money.format(totalCustomerBalance)}</strong><small>Across visible results</small></article>
        </section>

        <section className="admin-wallet-card">
          <div><span className="eyebrow">Admin account</span><h2>Move your own funds</h2><p className="muted">The administrator still has a normal bank account for deposits and transfers.</p></div>
          <div className="admin-wallet-actions">
            <button className="secondary-button" onClick={() => setModal({ type: 'ownDeposit' })}><Icon name="plus" /> Deposit</button>
            <button className="primary-button" onClick={() => setModal({ type: 'ownTransfer' })}><Icon name="send" /> Transfer</button>
          </div>
        </section>

        <section className="admin-panel" id="customers">
          <div className="section-heading admin-section-heading">
            <div><span className="eyebrow">Customer management</span><h2>Customers</h2></div>
            <form className="customer-search" onSubmit={(e) => { e.preventDefault(); loadCustomers(search) }}>
              <div className="search-field"><Icon name="search" size={18} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Name, username or account" aria-label="Search customers" /></div>
              <button className="primary-button" disabled={loadingCustomers}>{loadingCustomers ? 'Searching…' : 'Search'}</button>
              {search && <button type="button" className="secondary-button" onClick={() => { setSearch(''); loadCustomers('') }}>Clear</button>}
            </form>
          </div>

          <div className="customer-table-wrap">
            <table className="customer-table">
              <thead><tr><th>Customer</th><th>Account</th><th>Balance</th><th>Actions</th></tr></thead>
              <tbody>{customers.map((customer) => <tr key={customer.accountNumber}>
                <td><strong>{customer.fullName}</strong><span>@{customer.username}</span></td>
                <td><code>{customer.accountNumber}</code></td>
                <td><strong>{money.format(Number(customer.balance))}</strong></td>
                <td><div className="table-actions">
                  <button className="mini-button topup" onClick={() => setModal({ type: 'topup', customer })}>Top up</button>
                  <button className="mini-button debit" onClick={() => setModal({ type: 'debit', customer })}>Debit</button>
                  <button className="mini-button inspect" onClick={() => inspectCustomer(customer)}>Transactions</button>
                </div></td>
              </tr>)}</tbody>
            </table>
          </div>

          <div className="customer-card-list">
            {customers.map((customer) => <article className="customer-mobile-card" key={customer.accountNumber}>
              <div className="customer-mobile-head"><div><strong>{customer.fullName}</strong><span>@{customer.username}</span></div><strong>{money.format(Number(customer.balance))}</strong></div>
              <div className="customer-account-number">{customer.accountNumber}</div>
              <div className="customer-mobile-actions">
                <button className="mini-button topup" onClick={() => setModal({ type: 'topup', customer })}>+ Top up</button>
                <button className="mini-button debit" onClick={() => setModal({ type: 'debit', customer })}>− Debit</button>
                <button className="mini-button inspect" onClick={() => inspectCustomer(customer)}>History</button>
              </div>
            </article>)}
          </div>
          {!customers.length && !loadingCustomers && <div className="empty-state">No customers matched your search.</div>}
        </section>

        <section className="admin-panel inspector-panel" id="customer-inspector">
          <div className="section-heading">
            <div><span className="eyebrow">Transaction inspection</span><h2>{selected ? selected.fullName : 'Select a customer'}</h2>{selected && <p className="muted inspector-meta">{selected.accountNumber} · {money.format(Number(selected.balance))}</p>}</div>
          </div>
          {selected ? <div className="transactions">{selectedTransactions.length ? selectedTransactions.map((tx) => <TransactionRow key={tx.id} tx={tx} />) : <div className="empty-state">No transactions for this customer yet.</div>}</div> : <div className="empty-state">Choose “Transactions” or “History” from a customer row to inspect account activity.</div>}
        </section>

        <section className="admin-panel compact-history">
          <div className="section-heading"><div><span className="eyebrow">Administrator wallet</span><h2>Recent admin-account activity</h2></div></div>
          <div className="transactions">{adminTransactions.length ? adminTransactions.slice(0, 5).map((tx) => <TransactionRow key={tx.id} tx={tx} />) : <div className="empty-state">No admin-account transactions yet.</div>}</div>
        </section>
      </main>

      {modal?.type === 'topup' && <MoneyForm mode="topup" customer={modal.customer} onClose={() => setModal(null)} onSuccess={async () => { setModal(null); await refreshSelected(); notify('Customer balance topped up') }} />}
      {modal?.type === 'debit' && <MoneyForm mode="debit" customer={modal.customer} onClose={() => setModal(null)} onSuccess={async () => { setModal(null); await refreshSelected(); notify('Customer balance debited') }} />}
      {modal?.type === 'ownDeposit' && <OwnDeposit onClose={() => setModal(null)} onSuccess={async () => { setModal(null); await loadAdmin(); notify('Admin deposit completed') }} />}
      {modal?.type === 'ownTransfer' && <OwnTransfer currentAccount={account.accountNumber} onClose={() => setModal(null)} onSuccess={async () => { setModal(null); await Promise.all([loadAdmin(), loadCustomers(search)]); notify('Admin transfer completed') }} />}
      {toast && <div className="toast"><Icon name="check" /> {toast}</div>}
    </div>
  )
}
