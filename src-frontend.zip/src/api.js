const API_BASE = import.meta.env.VITE_API_BASE_URL || ''

async function parseResponse(response) {
  if (response.status === 204) return null

  const body = await response.json().catch(() => null)

  if (!response.ok) {
    const error = new Error(body?.message || `Request failed with status ${response.status}`)
    error.status = response.status
    throw error
  }

  return body
}

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  })

  return parseResponse(response)
}

async function getCsrf() {
  return request('/api/auth/csrf', { method: 'GET' })
}

async function post(path, body) {
  const csrf = await getCsrf()

  return request(path, {
    method: 'POST',
    headers: {
      [csrf.headerName]: csrf.token,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
}

export const api = {
  getCsrf,
  login: (username, password) => post('/api/auth/login', { username, password }),
  logout: () => post('/api/auth/logout'),
  me: () => request('/api/auth/me'),
  account: () => request('/api/account'),
  deposit: (amount) => post('/api/account/deposit', { amount }),
  transfer: (targetAccountNumber, amount, description) =>
    post('/api/account/transfer', { targetAccountNumber, amount, description }),
  transactions: (page = 0, size = 20) =>
    request(`/api/account/transactions?page=${page}&size=${size}`),

  adminCustomers: (search = '', page = 0, size = 20) =>
    request(`/api/admin/customers?search=${encodeURIComponent(search)}&page=${page}&size=${size}`),
  adminTopUp: (accountNumber, amount, description) =>
    post(`/api/admin/customers/${encodeURIComponent(accountNumber)}/top-up`, { amount, description }),
  adminDebit: (accountNumber, amount, description) =>
    post(`/api/admin/customers/${encodeURIComponent(accountNumber)}/debit`, { amount, description }),
  adminTransactions: (accountNumber, page = 0, size = 50) =>
    request(`/api/admin/customers/${encodeURIComponent(accountNumber)}/transactions?page=${page}&size=${size}`),
}
