import { useEffect, useMemo, useState } from 'react'
import { api } from './api'
import { Icon } from './icons'
import AdminDashboard from './AdminDashboard'

const money = new Intl.NumberFormat('en-PH', {
  style: 'currency',
  currency: 'PHP',
  minimumFractionDigits: 2,
})

const dateTime = new Intl.DateTimeFormat('en-PH', {
  dateStyle: 'medium',
  timeStyle: 'short',
})

function Login({ onLogin }) {
  const [username, setUsername] = useState('alice')
  const [password, setPassword] = useState('password123')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event) {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      await api.login(username, password)
      await onLogin()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="login-shell">
      <section className="login-copy">
        <div className="brand">
          <div className="brand-mark">N</div>
          <span>Northstar</span>
        </div>

        <div className="hero-copy">
          <span className="eyebrow">Simple banking, clearly designed</span>
          <h1>Your money at a glance.</h1>
          <p>
            A React + Spring demonstration with session login, deposits,
            transfers, transaction history, MySQL persistence, and a documented API.
          </p>
        </div>

        <div className="trust-row">
          <span>Spring Security</span>
          <span>CSRF protected</span>
          <span>Swagger documented</span>
        </div>
      </section>

      <section className="login-panel">
        <form className="auth-card" onSubmit={submit}>
          <div className="mobile-brand">
            <div className="brand-mark">N</div>
            <strong>Northstar</strong>
          </div>
          <span className="eyebrow">Demo account</span>
          <h2>Welcome back</h2>
          <p className="muted">Sign in to open your banking dashboard.</p>

          {error && <div className="alert error">{error}</div>}

          <label>
            <span>Username</span>
            <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
          </label>

          <label>
            <span>Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </label>

          <button className="primary-button" disabled={loading}>
            {loading ? 'Signing in…' : 'Sign in'}
          </button>

          <div className="demo-note">
            Try <code>alice / password123</code>, <code>bob / password123</code>, or <code>admin / password123</code>.
          </div>
        </form>
      </section>
    </main>
  )
}

function Modal({ title, children, onClose }) {
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section
        className="modal-card"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="modal-head">
          <div>
            <span className="eyebrow">Money movement</span>
            <h2>{title}</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Close">×</button>
        </div>
        {children}
      </section>
    </div>
  )
}

function TransactionRow({ tx }) {
  const outgoing = Number(tx.amount) < 0
  const titleMap = {
    DEPOSIT: 'Cash deposit',
    TRANSFER_OUT: 'Transfer sent',
    TRANSFER_IN: 'Transfer received',
    ADMIN_TOPUP: 'Admin top-up',
    ADMIN_DEBIT: 'Admin debit',
  }

  return (
    <div className="transaction-row">
      <div className={`tx-icon ${outgoing ? 'outgoing' : 'incoming'}`}>
        <Icon name={outgoing ? 'send' : 'plus'} size={18} />
      </div>
      <div className="tx-main">
        <strong>{titleMap[tx.type] || tx.type}</strong>
        <span>
          {tx.description || 'Banking transaction'}
          {tx.counterpartyAccountNumber ? ` · ${tx.counterpartyAccountNumber}` : ''}
        </span>
      </div>
      <div className="tx-meta">
        <strong className={outgoing ? 'negative' : 'positive'}>
          {outgoing ? '−' : '+'}{money.format(Math.abs(Number(tx.amount)))}
        </strong>
        <span>{dateTime.format(new Date(tx.createdAt))}</span>
      </div>
    </div>
  )
}

function Dashboard({ onUnauthenticated }) {
  const [account, setAccount] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [modal, setModal] = useState(null)
  const [toast, setToast] = useState('')
  const [error, setError] = useState('')
  const [balanceVisible, setBalanceVisible] = useState(true)

  async function refresh() {
    try {
      const [accountData, txPage] = await Promise.all([
        api.account(),
        api.transactions(0, 20),
      ])
      setAccount(accountData)
      setTransactions(txPage.content || [])
      setError('')
    } catch (err) {
      if (err.status === 401) onUnauthenticated()
      else setError(err.message)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  const recent = useMemo(() => transactions.slice(0, 8), [transactions])

  function notify(message) {
    setToast(message)
    window.setTimeout(() => setToast(''), 2600)
  }

  async function logout() {
    try {
      await api.logout()
    } finally {
      onUnauthenticated()
    }
  }

  async function copyAccount() {
    await navigator.clipboard.writeText(account.accountNumber)
    notify('Account number copied')
  }

  if (!account) {
    return <div className="loading-screen">Loading your account…</div>
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">N</div>
          <span>Northstar</span>
        </div>
        <nav>
          <a className="active" href="#top"><Icon name="home" /> Overview</a>
          <a href="#activity"><Icon name="history" /> Activity</a>
        </nav>
        <div className="sidebar-foot">
          <span className="avatar">{account.fullName.charAt(0)}</span>
          <div>
            <strong>{account.fullName}</strong>
            <span>@{account.username} · {account.role}</span>
          </div>
          <button className="icon-button" onClick={logout} title="Logout"><Icon name="logout" /></button>
        </div>
      </aside>

      <main className="dashboard" id="top">
        <header className="topbar">
          <div>
            <span className="eyebrow">{account.role === 'ADMIN' ? 'Administrator banking' : 'Personal banking'}</span>
            <h1>Good to see you, {account.fullName.split(' ')[0]}.</h1>
          </div>
          <button className="quiet-button" onClick={logout}><Icon name="logout" /> Sign out</button>
        </header>

        {error && <div className="alert error">{error}</div>}

        <section className="overview-grid">
          <article className="balance-card">
            <div className="card-top">
              <div>
                <span className="overline">Available balance</span>
                <div className="balance-line">
                  <h2>{balanceVisible ? money.format(Number(account.balance)) : '••••••••'}</h2>
                  <button
                    className="ghost-icon"
                    onClick={() => setBalanceVisible((value) => !value)}
                    aria-label="Toggle balance visibility"
                  >
                    <Icon name="eye" />
                  </button>
                </div>
              </div>
              <div className="wallet-icon"><Icon name="wallet" size={24} /></div>
            </div>

            <div className="account-strip">
              <div>
                <span>Everyday account</span>
                <strong>{account.accountNumber}</strong>
              </div>
              <button className="copy-button" onClick={copyAccount}>
                <Icon name="copy" size={16} /> Copy
              </button>
            </div>
          </article>

          <article className="quick-card">
            <div className="section-heading">
              <div>
                <span className="eyebrow">Quick actions</span>
                <h2>Move money</h2>
              </div>
            </div>
            <div className="action-grid">
              <button onClick={() => setModal('deposit')}>
                <span className="action-icon"><Icon name="plus" /></span>
                <strong>Deposit</strong>
                <span>Add funds</span>
              </button>
              <button onClick={() => setModal('transfer')}>
                <span className="action-icon"><Icon name="send" /></span>
                <strong>Transfer</strong>
                <span>Send cash</span>
              </button>
            </div>
          </article>
        </section>

        <section className="activity-card" id="activity">
          <div className="section-heading">
            <div>
              <span className="eyebrow">Account activity</span>
              <h2>Recent transactions</h2>
            </div>
            <span className="muted">{transactions.length} shown</span>
          </div>

          <div className="transactions">
            {recent.length
              ? recent.map((tx) => <TransactionRow key={tx.id} tx={tx} />)
              : <div className="empty-state">No transactions yet. Make a deposit to get started.</div>}
          </div>
        </section>
      </main>

      {modal === 'deposit' && (
        <DepositModal
          onClose={() => setModal(null)}
          onSuccess={async () => {
            setModal(null)
            await refresh()
            notify('Deposit completed')
          }}
        />
      )}

      {modal === 'transfer' && (
        <TransferModal
          currentAccount={account.accountNumber}
          onClose={() => setModal(null)}
          onSuccess={async () => {
            setModal(null)
            await refresh()
            notify('Transfer completed')
          }}
        />
      )}

      {toast && <div className="toast"><Icon name="check" /> {toast}</div>}
    </div>
  )
}

function DepositModal({ onClose, onSuccess }) {
  const [amount, setAmount] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event) {
    event.preventDefault()
    setLoading(true)
    setError('')
    try {
      await api.deposit(Number(amount))
      await onSuccess()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal title="Deposit funds" onClose={onClose}>
      <form className="modal-form" onSubmit={submit}>
        {error && <div className="alert error">{error}</div>}
        <label>
          <span>Amount</span>
          <div className="money-input">
            <b>₱</b>
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              autoFocus
              required
            />
          </div>
        </label>
        <div className="modal-actions">
          <button type="button" className="secondary-button" onClick={onClose}>Cancel</button>
          <button className="primary-button" disabled={loading}>
            {loading ? 'Depositing…' : 'Deposit'}
          </button>
        </div>
      </form>
    </Modal>
  )
}

function TransferModal({ currentAccount, onClose, onSuccess }) {
  const defaultTarget = currentAccount === '100000001' ? '100000002' : '100000001'
  const [target, setTarget] = useState(defaultTarget)
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event) {
    event.preventDefault()
    setLoading(true)
    setError('')
    try {
      await api.transfer(target, Number(amount), description)
      await onSuccess()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal title="Cash transfer" onClose={onClose}>
      <form className="modal-form" onSubmit={submit}>
        {error && <div className="alert error">{error}</div>}
        <label>
          <span>Recipient account</span>
          <input value={target} onChange={(e) => setTarget(e.target.value)} required />
        </label>
        <label>
          <span>Amount</span>
          <div className="money-input">
            <b>₱</b>
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              required
            />
          </div>
        </label>
        <label>
          <span>Description</span>
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength="200"
            placeholder="Optional note"
          />
        </label>
        <div className="modal-actions">
          <button type="button" className="secondary-button" onClick={onClose}>Cancel</button>
          <button className="primary-button" disabled={loading}>
            {loading ? 'Sending…' : 'Send money'}
          </button>
        </div>
      </form>
    </Modal>
  )
}

export default function App() {
  const [status, setStatus] = useState('loading')
  const [currentUser, setCurrentUser] = useState(null)

  async function checkSession() {
    try {
      const me = await api.me()
      setCurrentUser(me)
      setStatus('authenticated')
    } catch {
      setCurrentUser(null)
      setStatus('guest')
    }
  }

  useEffect(() => {
    checkSession()
  }, [])

  if (status === 'loading') {
    return <div className="loading-screen">Connecting to your bank…</div>
  }

  if (status === 'guest') {
    return <Login onLogin={checkSession} />
  }

  if (currentUser?.role === 'ADMIN') {
    return <AdminDashboard onUnauthenticated={() => { setCurrentUser(null); setStatus('guest') }} />
  }

  return <Dashboard onUnauthenticated={() => { setCurrentUser(null); setStatus('guest') }} />
}
