package com.example.banking.service;

import com.example.banking.domain.Account;
import com.example.banking.domain.AppUser;
import com.example.banking.domain.BankTransaction;
import com.example.banking.domain.TransactionType;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.BankTransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdminBankingServiceTest {

    @Mock private AccountRepository accounts;
    @Mock private BankTransactionRepository transactions;

    private AdminBankingService service;
    private Account customer;

    @BeforeEach
    void setUp() {
        service = new AdminBankingService(accounts, transactions);
        customer = account("alice", "Alice Santos", "USER", "100000001", "500.00");
    }

    @Test
    void topUpAddsCustomerBalanceAndCreatesAdminTransaction() {
        when(accounts.findByAccountNumberForUpdate("100000001")).thenReturn(Optional.of(customer));
        when(accounts.save(any(Account.class))).thenAnswer(inv -> inv.getArgument(0));
        when(transactions.save(any(BankTransaction.class))).thenAnswer(inv -> inv.getArgument(0));

        var response = service.topUp("admin", "100000001", new BigDecimal("125.50"), "Cash desk");

        assertThat(response.balance()).isEqualByComparingTo("625.50");
        ArgumentCaptor<BankTransaction> captor = ArgumentCaptor.forClass(BankTransaction.class);
        verify(transactions).save(captor.capture());
        assertThat(captor.getValue().getType()).isEqualTo(TransactionType.ADMIN_TOPUP);
        assertThat(captor.getValue().getAmount()).isEqualByComparingTo("125.50");
        assertThat(captor.getValue().getDescription()).contains("@admin");
    }

    @Test
    void debitSubtractsCustomerBalanceAndCreatesNegativeTransaction() {
        when(accounts.findByAccountNumberForUpdate("100000001")).thenReturn(Optional.of(customer));
        when(accounts.save(any(Account.class))).thenAnswer(inv -> inv.getArgument(0));
        when(transactions.save(any(BankTransaction.class))).thenAnswer(inv -> inv.getArgument(0));

        var response = service.debit("admin", "100000001", new BigDecimal("75.00"), "Correction");

        assertThat(response.balance()).isEqualByComparingTo("425.00");
        ArgumentCaptor<BankTransaction> captor = ArgumentCaptor.forClass(BankTransaction.class);
        verify(transactions).save(captor.capture());
        assertThat(captor.getValue().getType()).isEqualTo(TransactionType.ADMIN_DEBIT);
        assertThat(captor.getValue().getAmount()).isEqualByComparingTo("-75.00");
    }

    @Test
    void debitRejectsInsufficientCustomerFunds() {
        when(accounts.findByAccountNumberForUpdate("100000001")).thenReturn(Optional.of(customer));

        assertThatThrownBy(() -> service.debit("admin", "100000001", new BigDecimal("999.00"), null))
                .isInstanceOf(BankingException.class)
                .hasMessageContaining("insufficient funds");

        verify(accounts, never()).save(any());
        verify(transactions, never()).save(any());
    }

    @Test
    void adjustmentsCannotTargetAdminAccount() {
        Account admin = account("admin", "Bank Administrator", "ADMIN", "900000001", "1000.00");
        when(accounts.findByAccountNumberForUpdate("900000001")).thenReturn(Optional.of(admin));

        assertThatThrownBy(() -> service.topUp("admin", "900000001", new BigDecimal("10.00"), null))
                .isInstanceOf(BankingException.class)
                .hasMessageContaining("customer accounts");
    }

    private Account account(String username, String fullName, String role, String accountNumber, String balance) {
        AppUser user = new AppUser();
        user.setUsername(username);
        user.setFullName(fullName);
        user.setRole(role);
        user.setPassword("encoded");

        Account account = new Account();
        account.setUser(user);
        account.setAccountNumber(accountNumber);
        account.setBalance(new BigDecimal(balance));
        return account;
    }
}
