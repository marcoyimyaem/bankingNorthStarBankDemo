package com.example.banking.service;

import com.example.banking.api.dto.AccountResponse;
import com.example.banking.domain.Account;
import com.example.banking.domain.AppUser;
import com.example.banking.domain.BankTransaction;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.BankTransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BankingServiceTest {

    @Mock private AccountRepository accounts;
    @Mock private BankTransactionRepository transactions;

    private BankingService service;
    private Account alice;
    private Account bob;

    @BeforeEach
    void setUp() {
        service = new BankingService(accounts, transactions);
        alice = account("alice", "Alice Santos", "100000001", "500.00");
        bob = account("bob", "Bob Reyes", "100000002", "100.00");
    }

    @Test
    void depositAddsBalanceAndCreatesTransaction() {
        when(accounts.findByUsernameForUpdate("alice")).thenReturn(Optional.of(alice));
        when(accounts.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactions.save(any(BankTransaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        AccountResponse response = service.deposit("alice", new BigDecimal("25.50"));

        assertThat(response.balance()).isEqualByComparingTo("525.50");

        ArgumentCaptor<BankTransaction> txCaptor = ArgumentCaptor.forClass(BankTransaction.class);
        verify(transactions).save(txCaptor.capture());
        assertThat(txCaptor.getValue().getAmount()).isEqualByComparingTo("25.50");
    }

    @Test
    void transferMovesMoneyAndCreatesTwoTransactions() {
        when(accounts.findByUsernameForUpdate("alice")).thenReturn(Optional.of(alice));
        when(accounts.findByAccountNumberForUpdate("100000002")).thenReturn(Optional.of(bob));
        when(accounts.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactions.save(any(BankTransaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        AccountResponse response = service.transfer(
                "alice", "100000002", new BigDecimal("40.00"), "Dinner");

        assertThat(response.balance()).isEqualByComparingTo("460.00");
        assertThat(bob.getBalance()).isEqualByComparingTo("140.00");
        verify(transactions, times(2)).save(any(BankTransaction.class));
    }

    @Test
    void transferRejectsInsufficientFunds() {
        when(accounts.findByUsernameForUpdate("alice")).thenReturn(Optional.of(alice));
        when(accounts.findByAccountNumberForUpdate("100000002")).thenReturn(Optional.of(bob));

        assertThatThrownBy(() ->
                service.transfer("alice", "100000002", new BigDecimal("999.00"), "Too much"))
                .isInstanceOf(BankingException.class)
                .hasMessage("Insufficient funds");

        verify(accounts, never()).save(any());
        verify(transactions, never()).save(any());
    }

    private Account account(
            String username,
            String fullName,
            String accountNumber,
            String balance) {
        AppUser user = new AppUser();
        user.setUsername(username);
        user.setFullName(fullName);
        user.setPassword("encoded");

        Account account = new Account();
        account.setUser(user);
        account.setAccountNumber(accountNumber);
        account.setBalance(new BigDecimal(balance));
        return account;
    }
}
