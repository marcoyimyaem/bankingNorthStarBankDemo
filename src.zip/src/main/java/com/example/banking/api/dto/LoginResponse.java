package com.example.banking.api.dto;

public record LoginResponse(
        String username,
        String fullName,
        String role,
        String accountNumber
) {}
