package com.example.banking.api.dto;

import java.math.BigDecimal;

public record AccountResponse(
        String username,
        String fullName,
        String role,
        String accountNumber,
        BigDecimal balance
) {}
