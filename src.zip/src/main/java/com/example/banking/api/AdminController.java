package com.example.banking.api;

import com.example.banking.api.dto.AdminBalanceAdjustmentRequest;
import com.example.banking.api.dto.AdminCustomerResponse;
import com.example.banking.api.dto.TransactionResponse;
import com.example.banking.service.AdminBankingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/api/admin")
@Tag(name = "Administration", description = "Admin-only customer account management")
@SecurityRequirement(name = "sessionCookie")
public class AdminController {

    private final AdminBankingService adminBankingService;

    public AdminController(AdminBankingService adminBankingService) {
        this.adminBankingService = adminBankingService;
    }

    @GetMapping("/customers")
    @Operation(summary = "List or search customers")
    public Page<AdminCustomerResponse> customers(
            @RequestParam(defaultValue = "") String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return adminBankingService.customers(search, page, size);
    }

    @PostMapping("/customers/{accountNumber}/top-up")
    @Operation(summary = "Top up a customer balance")
    @SecurityRequirement(name = "csrfHeader")
    public AdminCustomerResponse topUp(
            Principal principal,
            @PathVariable String accountNumber,
            @Valid @RequestBody AdminBalanceAdjustmentRequest request) {
        return adminBankingService.topUp(
                principal.getName(), accountNumber, request.amount(), request.description());
    }

    @PostMapping("/customers/{accountNumber}/debit")
    @Operation(summary = "Debit a customer balance")
    @SecurityRequirement(name = "csrfHeader")
    public AdminCustomerResponse debit(
            Principal principal,
            @PathVariable String accountNumber,
            @Valid @RequestBody AdminBalanceAdjustmentRequest request) {
        return adminBankingService.debit(
                principal.getName(), accountNumber, request.amount(), request.description());
    }

    @GetMapping("/customers/{accountNumber}/transactions")
    @Operation(summary = "Inspect a customer's transaction history")
    public Page<TransactionResponse> transactions(
            @PathVariable String accountNumber,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {
        return adminBankingService.customerTransactions(accountNumber, page, size);
    }
}
