package com.example.banking.api.dto;

import com.example.banking.domain.TransactionType;
import java.math.BigDecimal;
import java.time.Instant;

public record TransactionResponse(
        Long id,
        TransactionType type,
        BigDecimal amount,
        String reference,
        String counterpartyAccountNumber,
        String description,
        Instant createdAt
) {}
