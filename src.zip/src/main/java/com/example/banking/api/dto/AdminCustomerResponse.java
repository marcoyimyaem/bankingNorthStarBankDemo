package com.example.banking.api.dto;

import java.math.BigDecimal;

public record AdminCustomerResponse(
        String username,
        String fullName,
        String accountNumber,
        BigDecimal balance
) {}
