package com.example.banking.api.dto;

public record CsrfResponse(
        String headerName,
        String parameterName,
        String token
) {}
