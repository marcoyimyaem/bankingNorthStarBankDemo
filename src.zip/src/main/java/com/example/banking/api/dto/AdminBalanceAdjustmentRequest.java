package com.example.banking.api.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

public record AdminBalanceAdjustmentRequest(
        @NotNull @DecimalMin(value = "0.01") BigDecimal amount,
        @Size(max = 160) String description
) {}
