package com.example.banking.api;

import com.example.banking.api.dto.AccountResponse;
import com.example.banking.api.dto.DepositRequest;
import com.example.banking.api.dto.TransactionResponse;
import com.example.banking.api.dto.TransferRequest;
import com.example.banking.service.BankingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/api/account")
@Tag(name = "Banking", description = "Authenticated account operations")
@SecurityRequirement(name = "sessionCookie")
public class AccountController {

    private final BankingService bankingService;

    public AccountController(BankingService bankingService) {
        this.bankingService = bankingService;
    }

    @GetMapping
    @Operation(summary = "Get account summary")
    public AccountResponse account(Principal principal) {
        return bankingService.getAccount(principal.getName());
    }

    @PostMapping("/deposit")
    @Operation(summary = "Deposit cash", description = "Adds a positive amount to the current user's account.")
    @SecurityRequirement(name = "csrfHeader")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Deposit completed"),
            @ApiResponse(responseCode = "400", description = "Invalid amount"),
            @ApiResponse(responseCode = "401", description = "Not authenticated")
    })
    public AccountResponse deposit(
            Principal principal,
            @Valid @RequestBody DepositRequest request) {
        return bankingService.deposit(principal.getName(), request.amount());
    }

    @PostMapping("/transfer")
    @Operation(summary = "Transfer cash", description = "Moves funds to another account and creates matching outgoing/incoming transaction records.")
    @SecurityRequirement(name = "csrfHeader")
    public AccountResponse transfer(
            Principal principal,
            @Valid @RequestBody TransferRequest request) {
        return bankingService.transfer(
                principal.getName(),
                request.targetAccountNumber(),
                request.amount(),
                request.description());
    }

    @GetMapping("/transactions")
    @Operation(summary = "Transaction history", description = "Returns newest transactions first.")
    public Page<TransactionResponse> transactions(
            Principal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return bankingService.getTransactions(principal.getName(), page, size);
    }
}
