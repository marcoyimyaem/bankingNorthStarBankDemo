package com.example.banking.api;

import com.example.banking.api.dto.AccountResponse;
import com.example.banking.api.dto.CsrfResponse;
import com.example.banking.api.dto.LoginRequest;
import com.example.banking.api.dto.LoginResponse;
import com.example.banking.service.BankingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Authentication", description = "Session login, logout, current-user and CSRF endpoints")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final SecurityContextRepository securityContextRepository;
    private final BankingService bankingService;

    public AuthController(
            AuthenticationManager authenticationManager,
            SecurityContextRepository securityContextRepository,
            BankingService bankingService) {
        this.authenticationManager = authenticationManager;
        this.securityContextRepository = securityContextRepository;
        this.bankingService = bankingService;
    }

    @GetMapping("/csrf")
    @Operation(summary = "Get a CSRF token", description = "Call this before POST requests and send the token using the returned header name.")
    public CsrfResponse csrf(CsrfToken token) {
        return new CsrfResponse(token.getHeaderName(), token.getParameterName(), token.getToken());
    }

    @PostMapping("/login")
    @Operation(summary = "Login", description = "Authenticates a demo user and stores authentication in an HTTP session. Fetch /api/auth/csrf first.")
    @SecurityRequirement(name = "csrfHeader")
    public LoginResponse login(
            @Valid @RequestBody LoginRequest requestBody,
            HttpServletRequest request,
            HttpServletResponse response) {

        Authentication authentication = authenticationManager.authenticate(
                UsernamePasswordAuthenticationToken.unauthenticated(
                        requestBody.username(),
                        requestBody.password()));

        if (request.getSession(false) != null) {
            request.changeSessionId();
        }

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authentication);
        SecurityContextHolder.setContext(context);
        securityContextRepository.saveContext(context, request, response);

        AccountResponse account = bankingService.getAccount(authentication.getName());
        return new LoginResponse(account.username(), account.fullName(), account.role(), account.accountNumber());
    }

    @PostMapping("/logout")
    @Operation(summary = "Logout", description = "Invalidates the current HTTP session.")
    @SecurityRequirement(name = "csrfHeader")
    public ResponseEntity<Void> logout(HttpServletRequest request) {
        if (request.getSession(false) != null) {
            request.getSession(false).invalidate();
        }
        SecurityContextHolder.clearContext();
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/me")
    @Operation(summary = "Current user", description = "Returns the authenticated user's identity and account number.")
    public LoginResponse me(Principal principal) {
        AccountResponse account = bankingService.getAccount(principal.getName());
        return new LoginResponse(account.username(), account.fullName(), account.role(), account.accountNumber());
    }
}
