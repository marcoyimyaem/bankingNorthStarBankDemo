package com.example.banking.service;

import com.example.banking.api.dto.AdminCustomerResponse;
import com.example.banking.api.dto.TransactionResponse;
import com.example.banking.domain.Account;
import com.example.banking.domain.BankTransaction;
import com.example.banking.domain.TransactionType;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.BankTransactionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

@Service
public class AdminBankingService {

    private final AccountRepository accounts;
    private final BankTransactionRepository transactions;

    public AdminBankingService(AccountRepository accounts, BankTransactionRepository transactions) {
        this.accounts = accounts;
        this.transactions = transactions;
    }

    @Transactional(readOnly = true)
    public Page<AdminCustomerResponse> customers(String search, int page, int size) {
        String safeSearch = search == null ? "" : search.trim();
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), 100);
        return accounts.searchCustomers(safeSearch, PageRequest.of(safePage, safeSize))
                .map(this::toCustomerResponse);
    }

    @Transactional
    public AdminCustomerResponse topUp(String adminUsername, String accountNumber, BigDecimal rawAmount, String description) {
        BigDecimal amount = normalizeAmount(rawAmount);
        Account account = customerForUpdate(accountNumber);
        account.setBalance(account.getBalance().add(amount));
        accounts.save(account);
        saveAdjustment(account, TransactionType.ADMIN_TOPUP, amount, adminUsername,
                description, "Administrator top-up");
        return toCustomerResponse(account);
    }

    @Transactional
    public AdminCustomerResponse debit(String adminUsername, String accountNumber, BigDecimal rawAmount, String description) {
        BigDecimal amount = normalizeAmount(rawAmount);
        Account account = customerForUpdate(accountNumber);
        if (account.getBalance().compareTo(amount) < 0) {
            throw new BankingException("Customer has insufficient funds for this debit");
        }
        account.setBalance(account.getBalance().subtract(amount));
        accounts.save(account);
        saveAdjustment(account, TransactionType.ADMIN_DEBIT, amount.negate(), adminUsername,
                description, "Administrator debit");
        return toCustomerResponse(account);
    }

    @Transactional(readOnly = true)
    public Page<TransactionResponse> customerTransactions(String accountNumber, int page, int size) {
        Account account = accounts.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new BankingException("Customer account not found"));
        if (!"USER".equals(account.getUser().getRole())) {
            throw new BankingException("Only customer accounts can be inspected here");
        }
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), 100);
        return transactions
                .findByAccountIdOrderByCreatedAtDesc(account.getId(), PageRequest.of(safePage, safeSize))
                .map(this::toTransactionResponse);
    }

    private Account customerForUpdate(String accountNumber) {
        Account account = accounts.findByAccountNumberForUpdate(accountNumber)
                .orElseThrow(() -> new BankingException("Customer account not found"));
        if (!"USER".equals(account.getUser().getRole())) {
            throw new BankingException("Admin adjustments are only allowed on customer accounts");
        }
        return account;
    }

    private void saveAdjustment(
            Account account,
            TransactionType type,
            BigDecimal signedAmount,
            String adminUsername,
            String description,
            String defaultDescription) {
        BankTransaction tx = new BankTransaction();
        tx.setAccount(account);
        tx.setType(type);
        tx.setAmount(signedAmount);
        tx.setReference(reference());
        String note = description == null || description.isBlank() ? defaultDescription : description.trim();
        String auditDescription = note + " · by admin @" + adminUsername;
        tx.setDescription(auditDescription.length() > 200 ? auditDescription.substring(0, 200) : auditDescription);
        transactions.save(tx);
    }

    private BigDecimal normalizeAmount(BigDecimal amount) {
        if (amount == null) throw new BankingException("Amount is required");
        BigDecimal normalized = amount.setScale(2, RoundingMode.HALF_EVEN);
        if (normalized.compareTo(new BigDecimal("0.01")) < 0) {
            throw new BankingException("Amount must be at least 0.01");
        }
        return normalized;
    }

    private String reference() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
    }

    private AdminCustomerResponse toCustomerResponse(Account account) {
        return new AdminCustomerResponse(
                account.getUser().getUsername(),
                account.getUser().getFullName(),
                account.getAccountNumber(),
                account.getBalance());
    }

    private TransactionResponse toTransactionResponse(BankTransaction tx) {
        return new TransactionResponse(
                tx.getId(), tx.getType(), tx.getAmount(), tx.getReference(),
                tx.getCounterpartyAccountNumber(), tx.getDescription(), tx.getCreatedAt());
    }
}
