package com.example.banking.service;

import com.example.banking.api.dto.AccountResponse;
import com.example.banking.api.dto.TransactionResponse;
import com.example.banking.domain.Account;
import com.example.banking.domain.BankTransaction;
import com.example.banking.domain.TransactionType;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.BankTransactionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

@Service
public class BankingService {

    private final AccountRepository accounts;
    private final BankTransactionRepository transactions;

    public BankingService(AccountRepository accounts, BankTransactionRepository transactions) {
        this.accounts = accounts;
        this.transactions = transactions;
    }

    @Transactional(readOnly = true)
    public AccountResponse getAccount(String username) {
        Account account = accounts.findByUserUsername(username)
                .orElseThrow(() -> new BankingException("Account not found"));
        return toAccountResponse(account);
    }

    @Transactional
    public AccountResponse deposit(String username, BigDecimal rawAmount) {
        BigDecimal amount = normalizeAmount(rawAmount);

        Account account = accounts.findByUsernameForUpdate(username)
                .orElseThrow(() -> new BankingException("Account not found"));

        account.setBalance(account.getBalance().add(amount));
        accounts.save(account);

        BankTransaction tx = new BankTransaction();
        tx.setAccount(account);
        tx.setType(TransactionType.DEPOSIT);
        tx.setAmount(amount);
        tx.setReference(reference());
        tx.setDescription("Cash deposit");
        transactions.save(tx);

        return toAccountResponse(account);
    }

    @Transactional
    public AccountResponse transfer(
            String username,
            String targetAccountNumber,
            BigDecimal rawAmount,
            String description) {

        BigDecimal amount = normalizeAmount(rawAmount);

        Account source = accounts.findByUsernameForUpdate(username)
                .orElseThrow(() -> new BankingException("Source account not found"));

        if (source.getAccountNumber().equals(targetAccountNumber)) {
            throw new BankingException("You cannot transfer to the same account");
        }

        Account target = accounts.findByAccountNumberForUpdate(targetAccountNumber)
                .orElseThrow(() -> new BankingException("Target account not found"));

        if (source.getBalance().compareTo(amount) < 0) {
            throw new BankingException("Insufficient funds");
        }

        source.setBalance(source.getBalance().subtract(amount));
        target.setBalance(target.getBalance().add(amount));
        accounts.save(source);
        accounts.save(target);

        String transferReference = reference();
        String safeDescription = description == null || description.isBlank()
                ? "Account transfer"
                : description.trim();

        BankTransaction outgoing = new BankTransaction();
        outgoing.setAccount(source);
        outgoing.setType(TransactionType.TRANSFER_OUT);
        outgoing.setAmount(amount.negate());
        outgoing.setReference(transferReference);
        outgoing.setCounterpartyAccountNumber(target.getAccountNumber());
        outgoing.setDescription(safeDescription);
        transactions.save(outgoing);

        BankTransaction incoming = new BankTransaction();
        incoming.setAccount(target);
        incoming.setType(TransactionType.TRANSFER_IN);
        incoming.setAmount(amount);
        incoming.setReference(transferReference);
        incoming.setCounterpartyAccountNumber(source.getAccountNumber());
        incoming.setDescription(safeDescription);
        transactions.save(incoming);

        return toAccountResponse(source);
    }

    @Transactional(readOnly = true)
    public Page<TransactionResponse> getTransactions(String username, int page, int size) {
        Account account = accounts.findByUserUsername(username)
                .orElseThrow(() -> new BankingException("Account not found"));

        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), 100);

        return transactions
                .findByAccountIdOrderByCreatedAtDesc(account.getId(), PageRequest.of(safePage, safeSize))
                .map(this::toTransactionResponse);
    }

    private BigDecimal normalizeAmount(BigDecimal amount) {
        if (amount == null) {
            throw new BankingException("Amount is required");
        }

        BigDecimal normalized = amount.setScale(2, RoundingMode.HALF_EVEN);
        if (normalized.compareTo(new BigDecimal("0.01")) < 0) {
            throw new BankingException("Amount must be at least 0.01");
        }
        return normalized;
    }

    private String reference() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
    }

    private AccountResponse toAccountResponse(Account account) {
        return new AccountResponse(
                account.getUser().getUsername(),
                account.getUser().getFullName(),
                account.getUser().getRole(),
                account.getAccountNumber(),
                account.getBalance());
    }

    private TransactionResponse toTransactionResponse(BankTransaction tx) {
        return new TransactionResponse(
                tx.getId(),
                tx.getType(),
                tx.getAmount(),
                tx.getReference(),
                tx.getCounterpartyAccountNumber(),
                tx.getDescription(),
                tx.getCreatedAt());
    }
}
