package com.example.banking.domain;

public enum TransactionType {
    DEPOSIT,
    TRANSFER_OUT,
    TRANSFER_IN,
    ADMIN_TOPUP,
    ADMIN_DEBIT
}
