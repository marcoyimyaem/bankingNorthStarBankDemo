package com.example.banking.repository;

import com.example.banking.domain.Account;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Optional<Account> findByUserUsername(String username);
    Optional<Account> findByAccountNumber(String accountNumber);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from Account a join fetch a.user where a.user.username = :username")
    Optional<Account> findByUsernameForUpdate(@Param("username") String username);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from Account a join fetch a.user where a.accountNumber = :accountNumber")
    Optional<Account> findByAccountNumberForUpdate(@Param("accountNumber") String accountNumber);

    @Query(
            value = """
                    select a from Account a join fetch a.user u
                    where u.role = 'USER'
                      and (
                        :search = ''
                        or lower(u.username) like lower(concat('%', :search, '%'))
                        or lower(u.fullName) like lower(concat('%', :search, '%'))
                        or a.accountNumber like concat('%', :search, '%')
                      )
                    order by u.fullName asc
                    """,
            countQuery = """
                    select count(a) from Account a join a.user u
                    where u.role = 'USER'
                      and (
                        :search = ''
                        or lower(u.username) like lower(concat('%', :search, '%'))
                        or lower(u.fullName) like lower(concat('%', :search, '%'))
                        or a.accountNumber like concat('%', :search, '%')
                      )
                    """)
    Page<Account> searchCustomers(@Param("search") String search, Pageable pageable);
}
