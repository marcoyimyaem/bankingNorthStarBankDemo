package com.example.banking.config;

import com.example.banking.domain.Account;
import com.example.banking.domain.AppUser;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.AppUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner seedDemoData(
            AppUserRepository users,
            AccountRepository accounts,
            PasswordEncoder passwordEncoder) {
        return args -> {
            createUserIfMissing(users, accounts, passwordEncoder,
                    "alice", "Alice Santos", "USER", "100000001", new BigDecimal("5000.00"));
            createUserIfMissing(users, accounts, passwordEncoder,
                    "bob", "Bob Reyes", "USER", "100000002", new BigDecimal("2500.00"));
            createUserIfMissing(users, accounts, passwordEncoder,
                    "admin", "Bank Administrator", "ADMIN", "900000001", new BigDecimal("100000.00"));
        };
    }

    private void createUserIfMissing(
            AppUserRepository users,
            AccountRepository accounts,
            PasswordEncoder encoder,
            String username,
            String fullName,
            String role,
            String accountNumber,
            BigDecimal openingBalance) {

        if (users.existsByUsername(username)) {
            return;
        }

        AppUser user = new AppUser();
        user.setUsername(username);
        user.setFullName(fullName);
        user.setRole(role);
        user.setPassword(encoder.encode("password123"));
        user = users.save(user);

        Account account = new Account();
        account.setUser(user);
        account.setAccountNumber(accountNumber);
        account.setBalance(openingBalance);
        accounts.save(account);
    }
}
