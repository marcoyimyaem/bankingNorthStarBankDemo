package com.example.banking.web;

import com.example.banking.api.dto.AccountResponse;
import com.example.banking.service.BankingException;
import com.example.banking.service.BankingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;

@Controller
public class ServerUiController {

    private final BankingService bankingService;

    public ServerUiController(BankingService bankingService) {
        this.bankingService = bankingService;
    }

    @GetMapping("/")
    public String root() {
        return "redirect:/server-ui";
    }

    @GetMapping("/server-ui/login")
    public String login() {
        return "login";
    }

    @GetMapping("/server-ui")
    public String dashboard(Principal principal, Model model) {
        AccountResponse account = bankingService.getAccount(principal.getName());
        model.addAttribute("account", account);
        model.addAttribute("transactions",
                bankingService.getTransactions(principal.getName(), 0, 10).getContent());
        return "dashboard";
    }

    @PostMapping("/server-ui/deposit")
    public String deposit(
            Principal principal,
            @RequestParam BigDecimal amount,
            RedirectAttributes redirectAttributes) {
        try {
            bankingService.deposit(principal.getName(), amount);
            redirectAttributes.addFlashAttribute("success", "Deposit completed.");
        } catch (BankingException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/server-ui";
    }

    @PostMapping("/server-ui/transfer")
    public String transfer(
            Principal principal,
            @RequestParam String targetAccountNumber,
            @RequestParam BigDecimal amount,
            @RequestParam(required = false) String description,
            RedirectAttributes redirectAttributes) {
        try {
            bankingService.transfer(principal.getName(), targetAccountNumber, amount, description);
            redirectAttributes.addFlashAttribute("success", "Transfer completed.");
        } catch (BankingException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/server-ui";
    }
}
